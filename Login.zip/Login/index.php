<?php
# Initialize the session
session_start();

# Include connection
require_once "./config.php";

# If user is not logged in then redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== TRUE) {
  echo "<script>" . "window.location.href='./login.php';" . "</script>";
  exit;
}

# Fetch user data
$sql = "SELECT profile_photo FROM users WHERE id = ?";
if ($stmt = mysqli_prepare($link, $sql)) { // Initialize $stmt here
  mysqli_stmt_bind_param($stmt, "i", $param_id);
  $param_id = $_SESSION["id"]; // Assuming user ID is stored in session

  if (mysqli_stmt_execute($stmt)) {
    mysqli_stmt_bind_result($stmt, $profile_photo);
    mysqli_stmt_fetch($stmt);

    // Set default photo if none is found
    $profile_photo = $profile_photo ?: './img/blank-avatar.jpg';
  }
  mysqli_stmt_close($stmt);
} else {
  // Handle error if the statement could not be prepared
  echo "<script>" . "alert('Failed to fetch user data. Please try again later.');" . "</script>";
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User login system</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  <link rel="stylesheet" href="./css/main.css">
</head>

<body>
  <div class="container">
    <div class="alert alert-success my-5">
      Welcome! You are now signed in to your account.
    </div>
    <!-- User profile -->
    <div class="row justify-content-center">
      <div class="col-lg-5 text-center">
        <!-- Display user photo -->
        <img src="<?= htmlspecialchars($profile_photo); ?>" class="img-fluid rounded-circle mb-3" alt="User avatar" width="180">
        <h4 class="my-4">Hello, <?= htmlspecialchars($_SESSION["username"]); ?></h4>
        <a href="./logout.php" class="btn btn-primary">Log Out</a>
      </div>
    </div>
  </div>
</body>

</html>